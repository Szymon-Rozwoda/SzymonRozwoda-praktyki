﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gea_karciana_ryby_WPF
{
    enum Suits
    {
        Spades,
        Clubs,
        Diamonds,
        Hearts
    }
}
