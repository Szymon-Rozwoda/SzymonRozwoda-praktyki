﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
int number = 15;
number = number + 10;
number = 36 * 15;
number = 12 - (42 / 7);
number += 10;
number *= 3;
number = 71 / 3;
int count = 0;
count++;
count--;
string result = "czesc";
result += "i znowu " + result;
Console.WriteLine(result);
result = "wartosc wynosi: " + count;
Console.WriteLine(result);
result = "";

for (int i = 0; i < 8; i++)
{
    Console.WriteLine("x");
}
int wartosc = 4;
if(wartosc == 3)
{
    Console.WriteLine("wartosc jest rowna 3");
}
else
{
    Console.WriteLine("wartosc nie jest rowna 3");
}