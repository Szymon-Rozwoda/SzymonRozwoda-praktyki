﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Invaders.Model
{
    enum InvaderType
    {
        Bug,
        Saucer,
        Satellite,
        Spaceship,
        Star
    }
}
