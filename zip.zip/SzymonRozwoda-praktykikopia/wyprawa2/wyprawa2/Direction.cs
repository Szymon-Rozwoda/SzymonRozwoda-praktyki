﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wyprawa2
{
    public enum Direction
    {
        Up,
        Right,
        Down,
        Left
    }
}
