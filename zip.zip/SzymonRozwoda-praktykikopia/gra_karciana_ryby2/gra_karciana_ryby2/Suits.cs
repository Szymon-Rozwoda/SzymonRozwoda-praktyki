﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gra_karciana_ryby2
{
    enum Suits
    {
        Spades,
        Clubs,
        Diamonds,
        Hearts
    }
}
