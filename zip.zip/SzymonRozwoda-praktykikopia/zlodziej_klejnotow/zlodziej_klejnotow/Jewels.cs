﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zlodziej_klejnotow
{
    class Jewels
    {
        public string Sparkle()
        {
            return "Lśnimy i błyszczymy";
        }
    }
}
